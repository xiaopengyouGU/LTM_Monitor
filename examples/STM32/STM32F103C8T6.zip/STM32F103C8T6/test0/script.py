import subprocess
import sys
import os
import shutil
import argparse
import json

PROJECT_NAME = "test0"
BUILD_DIR = "build"
ELF_PATH = os.path.join(BUILD_DIR, f"{PROJECT_NAME}.elf")

def read_launch_config():
    """从 launch.json 中读取 OpenOCD 路径和脚本目录"""
    launch_file = os.path.join(os.path.dirname(__file__), ".vscode", "launch.json")
    if not os.path.exists(launch_file):
        print("❌ 找不到 .vscode/launch.json，请确保文件存在")
        return None, None

    with open(launch_file, "r", encoding="utf-8") as f:
        config = json.load(f)

    # 查找第一个 cortex-debug 配置
    for cfg in config.get("configurations", []):
        if cfg.get("type") == "cortex-debug":
            serverpath = cfg.get("serverpath")
            search_dir = cfg.get("searchDir", [])
            if serverpath and search_dir:
                return serverpath, search_dir[0]  # 取第一个脚本目录
    print("❌ launch.json 中未找到有效的 cortex-debug 配置")
    return None, None

def run_openocd_flash():
    """通过 OpenOCD 烧录固件"""
    openocd_path, script_dir = read_launch_config()
    if not openocd_path or not script_dir:
        return False

    if not os.path.exists(ELF_PATH):
        print(f"❌ 找不到 ELF 文件: {ELF_PATH}")
        return False

    # 清理路径：去除首尾空白，将所有反斜杠替换为正斜杠，并检查不可见字符
    elf_path = ELF_PATH.replace('\\', '/').strip()
    # 调试：打印路径的原始表示，便于发现不可见字符
    print(f"ELF_PATH (repr): {repr(elf_path)}")

    cmd = [
        openocd_path,
        "-s", script_dir,
        "-f", "interface/stlink.cfg",
        "-f", "target/stm32f1x.cfg",
        "-c", f'program "{elf_path}" verify reset exit'
    ]
    print(">>> 烧录到单片机 ...")
    result = subprocess.run(cmd, check=False)
    return result.returncode == 0

def run_cmake_configure(build_type="Debug"):
    compile_cmd = [
        "cmake",
        "-G", "MinGW Makefiles",
        "-B", BUILD_DIR,
        "-S", ".",
        f"-DCMAKE_BUILD_TYPE={build_type}",
    ]
    print(f">>> 配置 CMake (Build type: {build_type}) ...")
    result = subprocess.run(compile_cmd, check=False)
    return result.returncode == 0

def run_cmake_build():
    build_cmd = ["cmake", "--build", BUILD_DIR]
    print(">>> 构建项目 ...")
    result = subprocess.run(build_cmd, check=False)
    return result.returncode == 0

def clean_build():
    if os.path.exists(BUILD_DIR):
        print(f">>> 删除构建目录 {BUILD_DIR} ...")
        shutil.rmtree(BUILD_DIR, ignore_errors=True)
    else:
        print(">>> 构建目录不存在，无需清理。")

def main():
    parser = argparse.ArgumentParser(description="STM32 项目构建与烧录脚本")
    group = parser.add_mutually_exclusive_group()
    group.add_argument("-b", "--build-only", action="store_true", help="仅构建 Debug 版本（不烧录）")
    group.add_argument("-D", "--debug-run", action="store_true", help="构建并烧录 Debug 版本")
    group.add_argument("-R", "--release-run", action="store_true", help="构建并烧录 Release 版本")
    group.add_argument("-o", "--only-flash", action="store_true", help="仅烧录（使用已构建的 .elf 文件）")
    group.add_argument("-c", "--clean", action="store_true", help="仅清理构建目录")
    args = parser.parse_args()

    # 无参数：显示帮助
    if not any(vars(args).values()):
        parser.print_help()
        sys.exit(0)

    if args.clean:
        clean_build()
        return

    # 确定构建类型（仅当需要构建时）
    build_type = "Release" if args.release_run else "Debug"
    need_build = args.build_only or args.debug_run or args.release_run
    need_flash = args.debug_run or args.release_run or args.only_flash

    if need_build:
        if not run_cmake_configure(build_type):
            print("❌ CMake 配置失败")
            sys.exit(1)
        if not run_cmake_build():
            print("❌ 构建失败")
            sys.exit(1)

    if need_flash:
        if not run_openocd_flash():
            print("❌ 烧录失败")
            sys.exit(1)

    if args.build_only:
        print("✅ 构建完成 (Debug)")

if __name__ == "__main__":
    main()