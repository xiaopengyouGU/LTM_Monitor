/*
 * SPDX-License-Identifier: Apache-2.0
 * Change Logs:
 * Date           Author       Notes
 * 2025-12-8	  Lvtou		   The first version
 */
 
#include "ltmotorlib.h"
#include "driver_def.h"
#include "OLED.h"				//0.96寸 OLED， 4脚IIC

uint8_t raw_data[14] = {0};
#define RAW_2_ACC			0.00059855f
#define RAW_2_RAD			0.00013323f
void mpu6050_read(void)
{
	// //ltm_iic_read(iic1,raw_data,14);						/* read datas */
	// int16_t accel_x = (raw_data[0] << 8) | raw_data[1];
	// int16_t accel_y = (raw_data[2] << 8) | raw_data[3];
	// int16_t accel_z = (raw_data[4] << 8) | raw_data[5];
	// int16_t temp    = (raw_data[6] << 8) | raw_data[7];
	// int16_t gyro_x  = (raw_data[8] << 8) | raw_data[9];
	// int16_t gyro_y  = (raw_data[10] << 8) | raw_data[11];
	// int16_t gyro_z  = (raw_data[12] << 8) | raw_data[13];

	// printf("accel_x = %d, %.3f m/s^2 \n",accel_x,accel_x*RAW_2_ACC);
	// printf("accel_y = %d, %.3f m/s^2 \n",accel_y,accel_y*RAW_2_ACC);
	// printf("accel_z = %d, %.3f m/s^2 \n",accel_z,accel_z*RAW_2_ACC);
	// printf("temp = %d, %.1f degree \n",temp, temp/340.0f + 36.53);
	// printf("gyro_x = %d, %.3f rad/s \n",gyro_x, gyro_x*RAW_2_RAD);
	// printf("gyro_y = %d, %.3f rad/s \n",gyro_y, gyro_y*RAW_2_RAD);
	// printf("gyro_z = %d, %.3f rad/s \n",gyro_z, gyro_z*RAW_2_RAD);
	printf("******************************************* \n");
}

int main(void)
{
	ltm_driver_init();				/* init all hardware drivers */
	OLED_Init();
	ltm_led_on(LED_NUM_0);
	
	printf("Hello world! \n");
	uint32_t count = 0; 
	
	OLED_ShowString(0, 0, "Hello World!", OLED_8X16);
	OLED_ShowString(0, 16,"LTM_Monitor", OLED_8X16);
	OLED_ShowString(0, 32,"Version:0.1.0",OLED_8X16);
	OLED_ShowString(0, 48, "Lvtou (CSU)", OLED_8X16);
	/*调用OLED_Update函数，将OLED显存数组的内容更新到OLED硬件进行显示*/
	OLED_Update();							//这一步很关键！

	while(1)
	{
		lt_commut_process();				//解析通讯协议！

		float angle = (count % 2000) * _2_PI / 2000.0f;		//增加数据点数
		lt_commut_send_curve(1, lt_sin(angle));
		lt_commut_send_curve(2, lt_cos(angle));
		lt_commut_send_curve(3, 3);
		lt_commut_send_curve(4, -3);
		lt_commut_send_curve(5, 2.5);
		
		if(count % 10 == 0)					//发送5个通道的数据， 20ms一次
		{
			ltm_led_toggle(LED_NUM_0);
		}
		if(count % 100 == 0)
			ltm_led_toggle(LED_NUM_1);
		if(count % 500 == 0)
		{
			ltm_led_toggle(LED_NUM_2); 
			lt_commut_printf("Hello Lvtou");	//不需要发送换行符，上位机会自动换行
			//单片机的printf默认不支持浮点数，得手动配置
		}

		ltm_delay_ms(20);
		count++;
	}
}