/***************************************************************************************
  * 本程序由江协科技创建并免费开源共享
  * 你可以任意查看、使用和修改，并应用到自己的项目之中
  * 程序版权归江协科技所有，任何人或组织不得将其据为己有
  * 
  * 程序名称：				0.96寸OLED显示屏驱动程序（4针脚I2C接口）
  * 程序创建时间：			2023.10.24
  * 当前程序版本：			V2.0
  * 当前版本发布时间：		2024.10.20
  * 
  * 江协科技官方网站：		jiangxiekeji.com
  * 江协科技官方淘宝店：	jiangxiekeji.taobao.com
  * 程序介绍及更新动态：	jiangxiekeji.com/tutorial/oled.html
  * 
  * 如果你发现程序中的漏洞或者笔误，可通过邮件向我们反馈：feedback@jiangxiekeji.com
  * 发送邮件之前，你可以先到更新动态页面查看最新程序，如果此问题已经修改，则无需再发邮件
  ***************************************************************************************
  */

#include "ltmotorlib.h"
#include "OLED.h"

extern ltm_iic_driver* iic1;   // 外部提供的 I2C 驱动实例，需已初始化并设置地址为 0x3C

/* 显存数组 */
uint8_t OLED_DisplayBuf[8][128];
/* 工具函数（次方）*/
int OLED_Pow(uint32_t X, uint32_t Y)
{
    int Result = 1;
    while (Y--)
    {
        Result *= X;
    }
    return Result;
}

/* 私有函数声明 */
static void OLED_WriteCommand(uint8_t Command);
static void OLED_WriteData(uint8_t *Data, uint8_t Count);
static void OLED_SetCursor(uint8_t Page, uint8_t X);

/* 写命令 */
static void OLED_WriteCommand(uint8_t Command)
{
    iic1->data_addr = 0x00;          // 命令控制字节
    ltm_iic_write(iic1, &Command, 1);
}

/* 写数据（连续多字节） */
static void OLED_WriteData(uint8_t *Data, uint8_t Count)
{
    iic1->data_addr = 0x40;          // 数据控制字节
    ltm_iic_write(iic1, Data, Count);
}

/* 设置光标位置 */
static void OLED_SetCursor(uint8_t Page, uint8_t X)
{
    OLED_WriteCommand(0xB0 | Page);                     // 页地址
    OLED_WriteCommand(0x10 | ((X & 0xF0) >> 4));        // 列高4位
    OLED_WriteCommand(0x00 | (X & 0x0F));               // 列低4位
}

/* OLED 初始化 */
void OLED_Init(void)
{
    // 初始化命令序列
    OLED_WriteCommand(0xAE);    // 关闭显示

    OLED_WriteCommand(0xD5);    // 设置显示时钟分频
    OLED_WriteCommand(0x80);

    OLED_WriteCommand(0xA8);    // 设置多路复用率
    OLED_WriteCommand(0x3F);

    OLED_WriteCommand(0xD3);    // 设置显示偏移
    OLED_WriteCommand(0x00);

    OLED_WriteCommand(0x40);    // 设置显示开始行

    OLED_WriteCommand(0xA1);    // 设置左右方向（正常）

    OLED_WriteCommand(0xC8);    // 设置上下方向（正常）

    OLED_WriteCommand(0xDA);    // 设置COM引脚硬件配置
    OLED_WriteCommand(0x12);

    OLED_WriteCommand(0x81);    // 设置对比度
    OLED_WriteCommand(0xCF);

    OLED_WriteCommand(0xD9);    // 设置预充电周期
    OLED_WriteCommand(0xF1);

    OLED_WriteCommand(0xDB);    // 设置VCOMH
    OLED_WriteCommand(0x30);

    OLED_WriteCommand(0xA4);    // 设置整个显示打开/关闭

    OLED_WriteCommand(0xA6);    // 设置正常/反色显示

    OLED_WriteCommand(0x8D);    // 设置充电泵
    OLED_WriteCommand(0x14);

    OLED_WriteCommand(0xAF);    // 开启显示

    OLED_Clear();               // 清空显存
    OLED_Update();              // 更新显示，防止花屏
}

/* 更新整个显存到屏幕 */
void OLED_Update(void)
{
    for (uint8_t j = 0; j < 8; j++)
    {
        OLED_SetCursor(j, 0);
        OLED_WriteData(OLED_DisplayBuf[j], 128);
    }
}

/* 更新指定区域到屏幕 */
void OLED_UpdateArea(int16_t X, int16_t Y, uint8_t Width, uint8_t Height)
{
    int16_t Page = Y / 8;
    int16_t Page1 = (Y + Height - 1) / 8 + 1;
    if (Y < 0)
    {
        Page -= 1;
        Page1 -= 1;
    }

    for (int16_t j = Page; j < Page1; j++)
    {
        if (X >= 0 && X <= 127 && j >= 0 && j <= 7)
        {
            OLED_SetCursor(j, X);
            OLED_WriteData(&OLED_DisplayBuf[j][X], Width);
        }
    }
}

/* 清空显存 */
void OLED_Clear(void)
{
    for (uint8_t j = 0; j < 8; j++)
    {
        for (uint8_t i = 0; i < 128; i++)
        {
            OLED_DisplayBuf[j][i] = 0x00;
        }
    }
}

/* 清除指定区域 */
void OLED_ClearArea(int16_t X, int16_t Y, uint8_t Width, uint8_t Height)
{
    for (int16_t j = Y; j < Y + Height; j++)
    {
        for (int16_t i = X; i < X + Width; i++)
        {
            if (i >= 0 && i <= 127 && j >= 0 && j <= 63)
            {
                OLED_DisplayBuf[j / 8][i] &= ~(0x01 << (j % 8));
            }
        }
    }
}

/* 显存全部取反 */
void OLED_Reverse(void)
{
    for (uint8_t j = 0; j < 8; j++)
    {
        for (uint8_t i = 0; i < 128; i++)
        {
            OLED_DisplayBuf[j][i] ^= 0xFF;
        }
    }
}

/* 指定区域取反 */
void OLED_ReverseArea(int16_t X, int16_t Y, uint8_t Width, uint8_t Height)
{
    for (int16_t j = Y; j < Y + Height; j++)
    {
        for (int16_t i = X; i < X + Width; i++)
        {
            if (i >= 0 && i <= 127 && j >= 0 && j <= 63)
            {
                OLED_DisplayBuf[j / 8][i] ^= 0x01 << (j % 8);
            }
        }
    }
}

/* 显示一个字符 */
void OLED_ShowChar(int16_t X, int16_t Y, char Char, uint8_t FontSize)
{
    if (FontSize == OLED_8X16)
    {
        OLED_ShowImage(X, Y, 8, 16, OLED_F8x16[Char - ' ']);
    }
    else if (FontSize == OLED_6X8)
    {
        OLED_ShowImage(X, Y, 6, 8, OLED_F6x8[Char - ' ']);
    }
}

/* 显示字符串（仅支持ASCII码） */
void OLED_ShowString(int16_t X, int16_t Y, char *String, uint8_t FontSize)
{
    uint16_t i = 0;
    uint16_t XOffset = 0;

    while (String[i] != '\0')
    {
        // 仅处理单字节 ASCII 字符
        OLED_ShowChar(X + XOffset, Y, String[i], FontSize);
        XOffset += FontSize;
        i++;
    }
}

/* 显示无符号整数 */
void OLED_ShowNum(int16_t X, int16_t Y, uint32_t Number, uint8_t Length, uint8_t FontSize)
{
    for (uint8_t i = 0; i < Length; i++)
    {
        OLED_ShowChar(X + i * FontSize, Y, Number / OLED_Pow(10, Length - i - 1) % 10 + '0', FontSize);
    }
}

/* 显示有符号整数 */
void OLED_ShowSignedNum(int16_t X, int16_t Y, int32_t Number, uint8_t Length, uint8_t FontSize)
{
    if (Number >= 0)
    {
        OLED_ShowChar(X, Y, '+', FontSize);
    }
    else
    {
        OLED_ShowChar(X, Y, '-', FontSize);
        Number = -Number;
    }
    for (uint8_t i = 0; i < Length; i++)
    {
        OLED_ShowChar(X + (i + 1) * FontSize, Y, Number / OLED_Pow(10, Length - i - 1) % 10 + '0', FontSize);
    }
}

/* 显示十六进制数 */
void OLED_ShowHexNum(int16_t X, int16_t Y, uint32_t Number, uint8_t Length, uint8_t FontSize)
{
    for (uint8_t i = 0; i < Length; i++)
    {
        uint8_t SingleNumber = Number / OLED_Pow(16, Length - i - 1) % 16;
        if (SingleNumber < 10)
        {
            OLED_ShowChar(X + i * FontSize, Y, SingleNumber + '0', FontSize);
        }
        else
        {
            OLED_ShowChar(X + i * FontSize, Y, SingleNumber - 10 + 'A', FontSize);
        }
    }
}

/* 显示二进制数 */
void OLED_ShowBinNum(int16_t X, int16_t Y, uint32_t Number, uint8_t Length, uint8_t FontSize)
{
    for (uint8_t i = 0; i < Length; i++)
    {
        OLED_ShowChar(X + i * FontSize, Y, Number / OLED_Pow(2, Length - i - 1) % 2 + '0', FontSize);
    }
}

/* 显示浮点数 */
void OLED_ShowFloatNum(int16_t X, int16_t Y, double Number, uint8_t IntLength, uint8_t FraLength, uint8_t FontSize)
{
    uint32_t PowNum, IntNum, FraNum;

    if (Number >= 0)
    {
        OLED_ShowChar(X, Y, '+', FontSize);
    }
    else
    {
        OLED_ShowChar(X, Y, '-', FontSize);
        Number = -Number;
    }

    IntNum = (uint32_t)Number;
    Number -= IntNum;
    PowNum = OLED_Pow(10, FraLength);
    FraNum = (uint32_t)(Number * PowNum + 0.5);  // 四舍五入
    IntNum += FraNum / PowNum;                   // 处理进位

    OLED_ShowNum(X + FontSize, Y, IntNum, IntLength, FontSize);
    OLED_ShowChar(X + (IntLength + 1) * FontSize, Y, '.', FontSize);
    OLED_ShowNum(X + (IntLength + 2) * FontSize, Y, FraNum, FraLength, FontSize);
}

/* 显示图像 */
void OLED_ShowImage(int16_t X, int16_t Y, uint8_t Width, uint8_t Height, const uint8_t *Image)
{
    OLED_ClearArea(X, Y, Width, Height);

    for (uint8_t j = 0; j < (Height - 1) / 8 + 1; j++)
    {
        for (uint8_t i = 0; i < Width; i++)
        {
            if (X + i >= 0 && X + i <= 127)
            {
                int16_t Page = Y / 8;
                int16_t Shift = Y % 8;
                if (Y < 0)
                {
                    Page -= 1;
                    Shift += 8;
                }

                if (Page + j >= 0 && Page + j <= 7)
                {
                    OLED_DisplayBuf[Page + j][X + i] |= Image[j * Width + i] << Shift;
                }
                if (Page + j + 1 >= 0 && Page + j + 1 <= 7)
                {
                    OLED_DisplayBuf[Page + j + 1][X + i] |= Image[j * Width + i] >> (8 - Shift);
                }
            }
        }
    }
}

/* 格式化输出（printf风格） */
void OLED_Printf(int16_t X, int16_t Y, uint8_t FontSize, char *format, ...)
{
    char String[256];
    va_list arg;
    va_start(arg, format);
    vsprintf(String, format, arg);
    va_end(arg);
    OLED_ShowString(X, Y, String, FontSize);
}

/*****************江协科技|版权所有****************/
/*****************jiangxiekeji.com*****************/
