/*
 * SPDX-License-Identifier: Apache-2.0
 * Change Logs:
 * Date           Author       Notes
 * 2025-11-25  	  Lvtou		   The first version
 */
#include "ltmotorlib.h"
#include "driver_def.h"
/* debug hardware implementation */

void led_init(void)
{
    GPIO_InitTypeDef gpio_init_struct;
    
    LED0_GPIO_CLK_ENABLE();                                 /* LED0ʱ��ʹ�� */
    LED1_GPIO_CLK_ENABLE();                                 /* LED1ʱ��ʹ�� */
    LED2_GPIO_CLK_ENABLE();

    gpio_init_struct.Pin = LED0_GPIO_PIN;                   /* LED0���� */
    gpio_init_struct.Mode = GPIO_MODE_OUTPUT_PP;            /* ������� */
    gpio_init_struct.Pull = GPIO_PULLUP;                    /* ���� */
    gpio_init_struct.Speed = GPIO_SPEED_FREQ_HIGH;          /* ���� */
    HAL_GPIO_Init(LED0_GPIO_PORT, &gpio_init_struct);       /* ��ʼ��LED0���� */

    gpio_init_struct.Pin = LED1_GPIO_PIN;                   /* LED1���� */
    HAL_GPIO_Init(LED1_GPIO_PORT, &gpio_init_struct);       /* ��ʼ��LED1���� */

    gpio_init_struct.Pin = LED2_GPIO_PIN;
    HAL_GPIO_Init(LED2_GPIO_PORT,&gpio_init_struct);
	/* stop led */
	ltm_led_off(LED_NUM_0);
	ltm_led_off(LED_NUM_1);
    ltm_led_off(LED_NUM_2);
}

void key_init(void)
{
    // GPIO_InitTypeDef gpio_init_struct;                          /* GPIO���ò����洢���� */
    // KEY0_GPIO_CLK_ENABLE();                                     /* KEY0ʱ��ʹ�� */
    // KEY1_GPIO_CLK_ENABLE();                                     /* KEY1ʱ��ʹ�� */
    // KEY2_GPIO_CLK_ENABLE();                                     /* KEY2ʱ��ʹ�� */

    // gpio_init_struct.Pin = KEY0_GPIO_PIN;                       /* KEY0���� */
    // gpio_init_struct.Mode = GPIO_MODE_INPUT;                    /* ���� */
    // gpio_init_struct.Pull = GPIO_PULLUP;                        /* ���� */
    // gpio_init_struct.Speed = GPIO_SPEED_FREQ_HIGH;              /* ���� */
    // HAL_GPIO_Init(KEY0_GPIO_PORT, &gpio_init_struct);           /* KEY0����ģʽ����,�������� */

    // gpio_init_struct.Pin = KEY1_GPIO_PIN;                       /* KEY1���� */
    // gpio_init_struct.Mode = GPIO_MODE_INPUT;                    /* ���� */
    // gpio_init_struct.Pull = GPIO_PULLUP;                        /* ���� */
    // gpio_init_struct.Speed = GPIO_SPEED_FREQ_HIGH;              /* ���� */
    // HAL_GPIO_Init(KEY1_GPIO_PORT, &gpio_init_struct);           /* KEY1����ģʽ����,�������� */

    // gpio_init_struct.Pin = KEY2_GPIO_PIN;                       /* KEY2���� */
    // gpio_init_struct.Mode = GPIO_MODE_INPUT;                    /* ���� */
    // gpio_init_struct.Pull = GPIO_PULLUP;                        /* ���� */
    // gpio_init_struct.Speed = GPIO_SPEED_FREQ_HIGH;              /* ���� */
    // HAL_GPIO_Init(KEY2_GPIO_PORT, &gpio_init_struct);           /* KEY2����ģʽ����,�������� */
}

/********************************************************************************************/
/* communicator hardware implementation */
void drv_debug_init(void)
{
	led_init();
	key_init();
}


static uint8_t _key_read(uint8_t num)
{
	// if(num == KEY_NUM_0)	return HAL_GPIO_ReadPin(KEY0_GPIO_PORT,KEY0_GPIO_PIN);
	// if(num == KEY_NUM_1) 	return HAL_GPIO_ReadPin(KEY1_GPIO_PORT,KEY1_GPIO_PIN);
	// if(num == KEY_NUM_2) 	return HAL_GPIO_ReadPin(KEY2_GPIO_PORT,KEY2_GPIO_PIN);
	// return 1;
}	

uint8_t ltm_key_scan(uint8_t mode)
{
    // static uint8_t key_up = 1;  
    // uint8_t keyval = 0xFF;

    // if (mode) key_up = 1;       /* support constant pressing */

    // if (key_up && (_key_read(KEY_NUM_0) == 0 || _key_read(KEY_NUM_1) == 0 || _key_read(KEY_NUM_2) == 0))  /* �����ɿ���־Ϊ1, ��������һ������������ */
    // {
    //     ltm_delay_ms(10);          
    //     key_up = 0;

    //     if (_key_read(KEY_NUM_0) == 0)  keyval = KEY_NUM_0;

    //     if (_key_read(KEY_NUM_1) == 0)  keyval = KEY_NUM_1;

    //     if (_key_read(KEY_NUM_2) == 0)  keyval = KEY_NUM_2;
    // }
    // else if (_key_read(KEY_NUM_0) == 1 && _key_read(KEY_NUM_1) == 1 && _key_read(KEY_NUM_2) == 1)         /* û���κΰ�������, ��ǰ����ɿ� */
    // {
    //     key_up = 1;
    // }

    // return keyval;             
}

void ltm_led_on(uint8_t num)
{
	if(num == LED_NUM_0)	HAL_GPIO_WritePin(LED0_GPIO_PORT,LED0_GPIO_PIN,GPIO_PIN_RESET);
	if(num == LED_NUM_1) 	HAL_GPIO_WritePin(LED1_GPIO_PORT,LED1_GPIO_PIN,GPIO_PIN_RESET);
    if(num == LED_NUM_2) 	HAL_GPIO_WritePin(LED2_GPIO_PORT,LED2_GPIO_PIN,GPIO_PIN_RESET);
}

void ltm_led_off(uint8_t num)
{
	if(num == LED_NUM_0)	HAL_GPIO_WritePin(LED0_GPIO_PORT,LED0_GPIO_PIN,GPIO_PIN_SET);
	if(num == LED_NUM_1) 	HAL_GPIO_WritePin(LED1_GPIO_PORT,LED1_GPIO_PIN,GPIO_PIN_SET);
    if(num == LED_NUM_2) 	HAL_GPIO_WritePin(LED2_GPIO_PORT,LED2_GPIO_PIN,GPIO_PIN_SET);
}

void ltm_led_toggle(uint8_t num)
{
	if(num == LED_NUM_0)	HAL_GPIO_TogglePin(LED0_GPIO_PORT,LED0_GPIO_PIN);
	if(num == LED_NUM_1) 	HAL_GPIO_TogglePin(LED1_GPIO_PORT,LED1_GPIO_PIN);
    if(num == LED_NUM_2) 	HAL_GPIO_TogglePin(LED2_GPIO_PORT,LED2_GPIO_PIN);
}


