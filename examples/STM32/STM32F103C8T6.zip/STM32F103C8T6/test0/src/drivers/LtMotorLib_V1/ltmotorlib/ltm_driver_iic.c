#include "ltmotorlib.h"
/* iic communication driver */
static void _iic_start(ltm_iic_driver* iic);
static void _iic_stop(ltm_iic_driver* iic);
static void _iic_ack(ltm_iic_driver* iic);
static void _iic_nack(ltm_iic_driver* iic);
static uint8_t _iic_wait_ack(ltm_iic_driver* iic);
static void _iic_send_byte(ltm_iic_driver* iic, uint8_t value);
static uint8_t _iic_read_byte(ltm_iic_driver* iic, uint8_t ack);

static uint8_t _iic_check_ack(ltm_iic_driver* iic);
static uint8_t _iic_write_prepare(ltm_iic_driver* iic);


static void _iic_delay(void)
{
    ltm_delay_us(2);
}

void ltm_iic_set(ltm_iic_driver* iic, ltm_iic_config* config)
{
    if(iic == NULL || config == NULL) return;
    iic->addr = config->addr;
    iic->data_addr = config->data_addr;
    iic->ops = config->ops;
    if(config->ops->init)
    {
        config->ops->init(iic);
        _iic_stop(iic);                 /* stop all devices on the bus */
    }
}

void ltm_iic_write(ltm_iic_driver* iic, uint8_t* buf, uint8_t size)
{
    if(iic == NULL || buf == NULL || size == 0) return;

    if(_iic_write_prepare(iic)) return;
    /* send datas */
    for(uint8_t i = 0; i < size; i++) 
    {
        _iic_send_byte(iic, buf[i]);
        if(_iic_check_ack(iic)) return;
    }
    
    _iic_stop(iic);
}

void ltm_iic_read(ltm_iic_driver* iic,  uint8_t* buf, uint8_t size)
{
    if(iic == NULL || buf == NULL || size == 0) return;
     
    uint8_t dev_addr = (iic->addr << 1) | 0x01; /* read command */
    if(_iic_write_prepare(iic)) return;
    _iic_start(iic);                            /* restart */
    _iic_send_byte(iic,dev_addr);               /* send read command */
    if(_iic_check_ack(iic)) return;
    /* read data */
    uint8_t ack = 0;
    for(uint8_t i = 0; i < size; i++) 
    {
        /* final byte : send NACK, else : send ACK */
        ack = (i == (size - 1)) ? 0 : 1;
        buf[i] = _iic_read_byte(iic,ack);
    }
    
    _iic_stop(iic);
}

void ltm_iic_stop(ltm_iic_driver* iic)
{
    if(iic == NULL) return;
    _iic_stop(iic);
}

/**************************************************************************************/
static void _iic_start(ltm_iic_driver* iic)
{               
    iic->ops->sda(iic,1);
    iic->ops->scl(iic,1);
    _iic_delay();           /* START signal : SCL = 1, SDA 1 -> 0 */
    iic->ops->sda(iic,0);
    _iic_delay();
    iic->ops->scl(iic,0);   /* ready to send or receive data */
    _iic_delay();   
}

static void _iic_stop(ltm_iic_driver* iic)
{
    iic->ops->sda(iic,0);
    _iic_delay();           /* STOP signal : SCL = 1, SDA 0 -> 1 */
    iic->ops->scl(iic,1);
    _iic_delay();
    iic->ops->sda(iic,1);   /* release SDA bus */
    _iic_delay();           
}

static void _iic_ack(ltm_iic_driver* iic)
{
    iic->ops->sda(iic,0);   /* SCL 0 -> 1, SDA = 0, ACK */
    _iic_delay();
    iic->ops->scl(iic,1);
    _iic_delay();
    iic->ops->scl(iic,0);
    _iic_delay();
    iic->ops->sda(iic,1);   /* SDA can change when SCL 1 -> 0 */
    _iic_delay();
}

static void _iic_nack(ltm_iic_driver* iic)
{
    iic->ops->sda(iic,1);   /* SCL 0 -> 1, SDA = 1, NACK */
    _iic_delay();
    iic->ops->scl(iic,1);   /* produce a clock */
    _iic_delay();
    iic->ops->scl(iic,0);
    _iic_delay();
}

static uint8_t _iic_wait_ack(ltm_iic_driver* iic)
{
    uint8_t waittime = 0;
    uint8_t rack = 0;
    iic->ops->sda(iic,1);
    _iic_delay();
    iic->ops->scl(iic,1);   /* SCL=1, SLAVE can response ACK */
    _iic_delay();

    while (iic->ops->read_sda(iic))    /* wait response */
    {
        waittime++;

        if (waittime > 250)
        {
            rack = 1;
            break;
        }
    }

    iic->ops->scl(iic,0);   /* finish ACK check */
    _iic_delay();
    return rack;
}

static void _iic_send_byte(ltm_iic_driver* iic, uint8_t value)
{
    uint8_t i;
    
    for (i = 0; i < 8; i++)
    {
        iic->ops->sda(iic,(value & 0x80) >> 7);    /* send high bit at first */
        _iic_delay();
        iic->ops->scl(iic,1);
        _iic_delay();
        iic->ops->scl(iic,0);
        value <<= 1;    
    }
    iic->ops->sda(iic,1);         /* send finish, master release SDA bus */
}

static uint8_t _iic_read_byte(ltm_iic_driver* iic, uint8_t ack)
{
    uint8_t i, receive = 0;

    for (i = 0; i < 8; i++ )    /* read a byte */
    {
        receive <<= 1;          /* read high bit at first, so move left */
        iic->ops->scl(iic,1);
        _iic_delay();

        if (iic->ops->read_sda(iic))
        {
            receive++;
        }
        
        iic->ops->scl(iic,0);
        _iic_delay();
    }

    if (ack)
    {
        _iic_ack(iic);      /* send ACK */
    }
    else
    {
        _iic_nack(iic);      /* send NACK */
    }

    return receive;
}

static uint8_t _iic_check_ack(ltm_iic_driver* iic)
{
    if(_iic_wait_ack(iic)) 
    {
        _iic_stop(iic);
        return 1;
    }
    else return 0;
}

static uint8_t _iic_write_prepare(ltm_iic_driver* iic)
{
    _iic_start(iic);        
    /* send 7bit address + write bit, bit0 = 0 => write */
    uint8_t dev_addr = (iic->addr << 1);
    _iic_send_byte(iic, dev_addr);
    if(_iic_check_ack(iic)) return 1;
    /* send data address */
    uint8_t addr_high = (iic->data_addr >> 8) & 0xFF;   /* send high byte at first */
    uint8_t addr_low  = iic->data_addr & 0xFF;          /* then send low byte */
    if(addr_high != 0)                                  /* for some device, data address is 8 bits */
    {
        _iic_send_byte(iic, addr_high);
        if(_iic_check_ack(iic)) return 1;
    }
    _iic_send_byte(iic, addr_low);
    if(_iic_check_ack(iic)) return 1;
    
    return 0;
}