#ifndef __LTM_DRIVER_H__
#define __LTM_DRIVER_H__

#include "lt_def.h"

/******************************************************************************************/
void ltm_driver_init(void);							/* init all hardware drivers */
void ltm_motor_run(uint8_t loop_flag);				/* motor operation function */
/* driver init functions */
void drv_system_init(void);							/* system init function */
void drv_current_init(void);						/* current sense driver init function */
void drv_timer_init(void);							/* hardware timer driver function */
void drv_driver_init(void);							/* PWM driver init function */
void drv_sensor_init(void);							/* position sensor driver init function */
void drv_commut_init(void);							/* communicator init function */
void drv_debug_init(void);							/* debug init : key and led */
void drv_motor_init(void);							/* this is final init function, and must be inited finally!!! */
/* delay functions */
void ltm_delay_ms(uint32_t ms);
void ltm_delay_us(uint32_t us);
/* functions for debug */
void ltm_led_on(uint8_t num);
void ltm_led_off(uint8_t num);
void ltm_led_toggle(uint8_t num);
uint8_t ltm_key_scan(uint8_t mode);
/**********************************/
/* iic driver */
struct ltm_iic_driver_ops;
typedef struct 
{   
    uint8_t addr;               /* slave address */
    uint16_t data_addr;         /* data address */
    const struct ltm_iic_driver_ops* ops;
}ltm_iic_driver;

struct ltm_iic_driver_ops
{
    void (*init)(ltm_iic_driver* iic);
    void (*scl)(ltm_iic_driver* iic, uint8_t val);
    void (*sda)(ltm_iic_driver* iic, uint8_t val);
    uint8_t (*read_sda)(ltm_iic_driver* iic);
};

typedef struct 
{
    uint8_t addr;
    uint16_t data_addr;
    struct ltm_iic_driver_ops* ops;
}ltm_iic_config;

void ltm_iic_set(ltm_iic_driver*iic, ltm_iic_config* config);
void ltm_iic_read(ltm_iic_driver* iic, uint8_t* buf, uint8_t size);
void ltm_iic_write(ltm_iic_driver* iic, uint8_t* buf, uint8_t size);
void ltm_iic_stop(ltm_iic_driver* iic);

#endif
