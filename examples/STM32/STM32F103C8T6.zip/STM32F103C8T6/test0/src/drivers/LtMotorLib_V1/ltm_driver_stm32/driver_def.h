#ifndef __DRIVER_DEF_H__
#define __DRIVER_DEF_H__

#include "stm32f1xx.h"
#include "stm32f1xx_hal.h"
#include "core_cm3.h"

/* hardware specified delay functions */
void HAL_Delay(uint32_t Delay);            			/* delay function of HAL Library */
/* current sense hardware implementation */
/******************************************************************************************/
/* ADC Pins definition */
#define ADC_VBUS_CHX_GPIO_PORT              GPIOA                                               /* ��Դ��ѹ�ɼ����� */
#define ADC_VBUS_CHX_GPIO_PIN               GPIO_PIN_3
#define ADC_VBUS_CHX_GPIO_CLK_ENABLE()      do{ __HAL_RCC_GPIOA_CLK_ENABLE(); }while(0)

#define ADC_VTEMP_CHX_GPIO_PORT             GPIOC                                               /* �¶Ȳɼ����� */
#define ADC_VTEMP_CHX1_GPIO_PIN             GPIO_PIN_0
#define ADC_VTEMP_CHX_GPIO_CLK_ENABLE()     do{ __HAL_RCC_GPIOC_CLK_ENABLE(); }while(0)

#define ADC_AMPU_CHX_GPIO_PORT              GPIOC                                               /* U��ɼ����� */
#define ADC_AMPU_CHX_GPIO_PIN               GPIO_PIN_1
#define ADC_AMPU_CHX_GPIO_CLK_ENABLE()      do{ __HAL_RCC_GPIOC_CLK_ENABLE(); }while(0)

#define ADC_AMPV_CHX_GPIO_PORT              GPIOC                                               /* V��ɼ����� */
#define ADC_AMPV_CHX_GPIO_PIN               GPIO_PIN_2
#define ADC_AMPV_CHX_GPIO_CLK_ENABLE()      do{ __HAL_RCC_GPIOC_CLK_ENABLE(); }while(0)

#define ADC_AMPW_CHX_GPIO_PORT              GPIOC                                               /* W��ɼ����� */
#define ADC_AMPW_CHX_GPIO_PIN               GPIO_PIN_3
#define ADC_AMPW_CHX_GPIO_CLK_ENABLE()      do{ __HAL_RCC_GPIOC_CLK_ENABLE(); }while(0)


#define ADC_ADCX                            ADC1 
#define ADC_VBUS_CHX                        ADC_CHANNEL_4                                       /* ��Դ��ѹ�ɼ�ADCͨ�� */ 
#define ADC_VTEMP_CHX                       ADC_CHANNEL_6                                       /* �������¶Ȳɼ�ADCͨ�� */ 
#define ADC_AMPU_CHX                        ADC_CHANNEL_7                                       /* U������ɼ�ADCͨ�� */ 
#define ADC_AMPV_CHX                        ADC_CHANNEL_8                                       /* V������ɼ�ADCͨ�� */ 
#define ADC_AMPW_CHX                        ADC_CHANNEL_9                                       /* W������ɼ�ADCͨ�� */ 
#define ADC_ADCX_CHY_CLK_ENABLE()           do{ __HAL_RCC_ADC12_CLK_ENABLE(); }while(0)         /* ADC1 ʱ��ʹ�� */

#define ADC_DMA_BUF_SIZE        50                                  /* ÿ��ADCͨ���� DMA�ɼ����� */
#define ADC_CH_NUM              5                                   /* ADC channel num */
#define ADC_SUM                 ADC_CH_NUM * ADC_DMA_BUF_SIZE       /* �ܲɼ����� */

#define ADC_ADCX_DMASx                      DMA1_Channel1
#define ADC_ADCX_DMASx_REQUEST              DMA_REQUEST_ADC1        /* ADC1_DMA����Դ */
#define ADC_ADCX_DMASx_IRQn                 DMA1_Channel1_IRQn
#define ADC_ADCX_DMASx_IRQHandler           DMA1_Channel1_IRQHandler


extern uint16_t g_adc_dma_buf[ADC_SUM];                             /* ADC DMA ԭʼADC��ֵ */
extern uint16_t g_adc_val[ADC_CH_NUM];                              /* �˲����ADC��ֵ��������  */
extern ADC_HandleTypeDef g_adc_handle;                              /* ADC��� */

/******************************************************************************************/

/* communicator hardware implementation */
/*******************************************************************************************************/

#define USART_TX_GPIO_PORT              GPIOA
#define USART_TX_GPIO_PIN               GPIO_PIN_9
//#define USART_TX_GPIO_AF                GPIO_AF7_USART1
#define USART_TX_GPIO_CLK_ENABLE()      do{ __HAL_RCC_GPIOB_CLK_ENABLE(); }while(0)   /* ��������ʱ��ʹ�� */

#define USART_RX_GPIO_PORT              GPIOA
#define USART_RX_GPIO_PIN               GPIO_PIN_10
//#define USART_RX_GPIO_AF                GPIO_AF7_USART1
#define USART_RX_GPIO_CLK_ENABLE()      do{ __HAL_RCC_GPIOB_CLK_ENABLE(); }while(0)   /* ��������ʱ��ʹ�� */

#define USART_UX                        USART1
#define USART_UX_IRQn                   USART1_IRQn
#define USART_UX_IRQHandler             USART1_IRQHandler
#define USART_UX_CLK_ENABLE()           do{ __HAL_RCC_USART1_CLK_ENABLE(); }while(0)  /* USART1 ʱ��ʹ�� */

/*******************************************************************************************************/

#define USART_REC_LEN   200                     /* �����������ֽ��� 200 */
#define USART_EN_RX     1                       /* ʹ�ܣ�1��/��ֹ��0������1���� */
#define RXBUFFERSIZE    1                       /* �����С */
/******************************************************************************************/

/* timer driver hardware implementation */
/******************************************************************************************/
/* �߼���ʱ�� ���� */

/* TIM_CHxͨ�� ���ű�IO���� */
#define ATIM_TIMX_PWM_CH1_GPIO_PORT            GPIOA
#define ATIM_TIMX_PWM_CH1_GPIO_PIN             GPIO_PIN_8
#define ATIM_TIMX_PWM_CH1_GPIO_CLK_ENABLE()    do{  __HAL_RCC_GPIOA_CLK_ENABLE(); }while(0)     /* PA��ʱ��ʹ�� */

#define ATIM_TIMX_PWM_CH2_GPIO_PORT            GPIOA
#define ATIM_TIMX_PWM_CH2_GPIO_PIN             GPIO_PIN_9
#define ATIM_TIMX_PWM_CH2_GPIO_CLK_ENABLE()    do{  __HAL_RCC_GPIOA_CLK_ENABLE(); }while(0)     /* PA��ʱ��ʹ�� */

#define ATIM_TIMX_PWM_CH3_GPIO_PORT            GPIOA
#define ATIM_TIMX_PWM_CH3_GPIO_PIN             GPIO_PIN_10
#define ATIM_TIMX_PWM_CH3_GPIO_CLK_ENABLE()    do{  __HAL_RCC_GPIOA_CLK_ENABLE(); }while(0)     /* PA��ʱ��ʹ�� */

/* ���ű�IO���� */
#define M1_LOW_SIDE_U_PORT                      GPIOB
#define M1_LOW_SIDE_U_PIN                       GPIO_PIN_13
#define M1_LOW_SIDE_U_GPIO_CLK_ENABLE()         do{  __HAL_RCC_GPIOB_CLK_ENABLE(); }while(0)    /* PB��ʱ��ʹ�� */

#define M1_LOW_SIDE_V_PORT                      GPIOB
#define M1_LOW_SIDE_V_PIN                       GPIO_PIN_14
#define M1_LOW_SIDE_V_GPIO_CLK_ENABLE()         do{  __HAL_RCC_GPIOB_CLK_ENABLE(); }while(0)    /* PB��ʱ��ʹ�� */

#define M1_LOW_SIDE_W_PORT                      GPIOB
#define M1_LOW_SIDE_W_PIN                       GPIO_PIN_15
#define M1_LOW_SIDE_W_GPIO_CLK_ENABLE()         do{  __HAL_RCC_GPIOB_CLK_ENABLE(); }while(0)    /* PB��ʱ��ʹ�� */

/* ���õ�TIM1 */
//#define ATIM_TIMX_PWM_CHY_GPIO_AF              GPIO_AF6_TIM1

#define ATIM_TIMX_PWM                          TIM1
#define ATIM_TIMX_PWM_IRQn                     TIM1_UP_TIM16_IRQn
#define ATIM_TIMX_PWM_IRQHandler               TIM1_UP_TIM16_IRQHandler
#define ATIM_TIMX_PWM_CH1                      TIM_CHANNEL_1                                    /* ͨ��1 */
#define ATIM_TIMX_PWM_CH2                      TIM_CHANNEL_2                                    /* ͨ��2 */
#define ATIM_TIMX_PWM_CH3                      TIM_CHANNEL_3                                    /* ͨ��3 */
#define ATIM_TIMX_PWM_CHY_CLK_ENABLE()         do{ __HAL_RCC_TIM1_CLK_ENABLE(); }while(0)       /* TIM1 ʱ��ʹ�� */


extern TIM_HandleTypeDef g_atimx_handle;                                                        /* ��ʱ��x��� */

/******************************************************************************************/
/* ������ʱ�� ���� */

/******************************************************************************************/

/* PWM driver hardware part implementation */
/***************************************** ����оƬ��ɲ������ ***************************************************/

#define SHUTDOWN_PIN                        GPIO_PIN_13                                                         /* PC13 */
#define SHUTDOWN_PIN_GPIO                   GPIOC
#define SHUTDOWN_PIN_GPIO_CLK_ENABLE()      do{  __HAL_RCC_GPIOC_CLK_ENABLE(); }while(0)                        /* PC��ʱ��ʹ�� */
/***************************************** �����������ӿ� *************************************************/

#define HALL1_TIM_CH1_PIN                   GPIO_PIN_0      /* U */
#define HALL1_TIM_CH1_GPIO                  GPIOA
#define HALL1_U_GPIO_CLK_ENABLE()           do{  __HAL_RCC_GPIOA_CLK_ENABLE(); }while(0)    /* PA��ʱ��ʹ�� */

#define HALL1_TIM_CH2_PIN                   GPIO_PIN_1      /* V */
#define HALL1_TIM_CH2_GPIO                  GPIOA
#define HALL1_V_GPIO_CLK_ENABLE()           do{  __HAL_RCC_GPIOA_CLK_ENABLE(); }while(0)    /* PA��ʱ��ʹ�� */

#define HALL1_TIM_CH3_PIN                   GPIO_PIN_2      /* W */
#define HALL1_TIM_CH3_GPIO                  GPIOA
#define HALL1_W_GPIO_CLK_ENABLE()           do{  __HAL_RCC_GPIOA_CLK_ENABLE(); }while(0)    /* PA��ʱ��ʹ�� */

/*************************************************************************************************************/
/* hardware implementation for debug */
/******************************************************************************************/
/* ���� ���� */
#define LED0_GPIO_PORT                  GPIOC
#define LED0_GPIO_PIN                   GPIO_PIN_13
#define LED0_GPIO_CLK_ENABLE()          do{ __HAL_RCC_GPIOC_CLK_ENABLE(); }while(0)             /* PE��ʱ��ʹ�� */

#define LED1_GPIO_PORT                  GPIOB
#define LED1_GPIO_PIN                   GPIO_PIN_14
#define LED1_GPIO_CLK_ENABLE()          do{ __HAL_RCC_GPIOB_CLK_ENABLE(); }while(0)             /* PE��ʱ��ʹ�� */

#define LED2_GPIO_PORT                  GPIOB
#define LED2_GPIO_PIN                   GPIO_PIN_5
#define LED2_GPIO_CLK_ENABLE()          do{ __HAL_RCC_GPIOB_CLK_ENABLE(); }while(0)   

#define LED_NUM_0						0x00
#define LED_NUM_1						0x01
#define LED_NUM_2						0x02
/******************************************************************************************/
/******************************************************************************************/
// #define KEY0_GPIO_PORT                  GPIOE
// #define KEY0_GPIO_PIN                   GPIO_PIN_13
// #define KEY0_GPIO_CLK_ENABLE()          do{ __HAL_RCC_GPIOE_CLK_ENABLE(); }while(0)   /* PE��ʱ��ʹ�� */

// #define KEY1_GPIO_PORT                  GPIOE
// #define KEY1_GPIO_PIN                   GPIO_PIN_14
// #define KEY1_GPIO_CLK_ENABLE()          do{ __HAL_RCC_GPIOE_CLK_ENABLE(); }while(0)   /* PE��ʱ��ʹ�� */

// #define KEY2_GPIO_PORT                  GPIOE
// #define KEY2_GPIO_PIN                   GPIO_PIN_15
// #define KEY2_GPIO_CLK_ENABLE()          do{ __HAL_RCC_GPIOE_CLK_ENABLE(); }while(0)   /* PE��ʱ��ʹ�� */

// #define KEY_NUM_0						0x00
// #define KEY_NUM_1						0x01
// #define KEY_NUM_2						0x02
/******************************************************************************************/

#define MPU_6050_ADDR                   0x6B
#define MPU_6050_DATA_ADDR              0x3B
#define MPU_6050_DATA_SIZE              14      /* 14 byte */

#endif