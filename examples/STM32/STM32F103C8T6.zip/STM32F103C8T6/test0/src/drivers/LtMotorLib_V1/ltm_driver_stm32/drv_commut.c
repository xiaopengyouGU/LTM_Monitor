/*
 * SPDX-License-Identifier: Apache-2.0
 * Change Logs:
 * Date           Author       Notes
 * 2025-12-7      Lvtou        The first version
 * 2026-1-22     Modified     Adapted for STM32F103xE
 */
#include "ltmotorlib.h"
#include "driver_def.h"
#include "protocol.h"           //LTM_Monitor通讯协议

/* communicator hardware implementation */

#if 1 
#include <unistd.h>
#include <errno.h>
/* output remap - the key of printf */
int _write(int file, char *ptr, int len)
{
    int i;
    if (file == STDOUT_FILENO || file == STDERR_FILENO) {
        for (i = 0; i < len; i++) {
            while ((USART1->SR & USART_SR_TXE) == 0) {};
            USART1->DR = (uint8_t)ptr[i];        
        }
        return i;
    }
    
    errno = EIO;
    return -1;
}

#endif 
/***********************************************END*******************************************/
UART_HandleTypeDef g_uart1_handle;                  /* UART handle */

/**
 * @brief       USART initialization
 * @param       baudrate: Baud rate
 * @note        Ensure clock source is correctly configured in sys_stm32_clock_init()
 * @retval      None
 */
void usart_init(uint32_t baudrate)
{
    g_uart1_handle.Instance = USART1;                         /* USART1 */
    g_uart1_handle.Init.BaudRate = baudrate;                  /* Baud rate */
    g_uart1_handle.Init.WordLength = UART_WORDLENGTH_8B;      /* 8-bit data format */
    g_uart1_handle.Init.StopBits = UART_STOPBITS_1;           /* 1 stop bit */
    g_uart1_handle.Init.Parity = UART_PARITY_NONE;            /* No parity */
    g_uart1_handle.Init.HwFlowCtl = UART_HWCONTROL_NONE;      /* No hardware flow control */
    g_uart1_handle.Init.Mode = UART_MODE_TX_RX;               /* Transmit and receive mode */
    HAL_UART_Init(&g_uart1_handle);                           /* Initialize UART */
}

/**
 * @brief       UART MSP initialization
 * @param       huart: UART handle pointer
 * @note        Called by HAL_UART_Init()
 * @retval      None
 */
void HAL_UART_MspInit(UART_HandleTypeDef *huart)
{
    GPIO_InitTypeDef gpio_init_struct;
    
    if(huart->Instance == USART1)                             /* If it's USART1 */
    {
        /* Enable clocks */
        __HAL_RCC_USART1_CLK_ENABLE();                        /* USART1 clock */
        __HAL_RCC_GPIOA_CLK_ENABLE();                         /* GPIOA clock (PA9/PA10) */
        
        /* GPIO configuration for TX (PA9) */
        gpio_init_struct.Pin = GPIO_PIN_9;                    /* TX pin */
        gpio_init_struct.Mode = GPIO_MODE_AF_PP;              /* Alternate function push-pull */
        gpio_init_struct.Pull = GPIO_PULLUP;                  /* Pull-up */
        gpio_init_struct.Speed = GPIO_SPEED_FREQ_HIGH;        /* High speed */
        /* STM32F103 PA9 alternate function: GPIO_AF7_USART1 (but F1 HAL doesn't use Alternate field like F4/G4) */
        HAL_GPIO_Init(GPIOA, &gpio_init_struct);              /* Initialize TX pin */
        
        /* GPIO configuration for RX (PA10) */
        gpio_init_struct.Pin = GPIO_PIN_10;                   /* RX pin */
        gpio_init_struct.Mode = GPIO_MODE_INPUT;              /* Input mode (for RX) */
        gpio_init_struct.Pull = GPIO_PULLUP;                  /* Pull-up */
        gpio_init_struct.Speed = GPIO_SPEED_FREQ_HIGH;        /* High speed */
        HAL_GPIO_Init(GPIOA, &gpio_init_struct);              /* Initialize RX pin */
        
        __HAL_UART_DISABLE_IT(&g_uart1_handle, UART_IT_TC);   /* Disable transmission complete interrupt */
        
#if USART_EN_RX
        __HAL_UART_ENABLE_IT(&g_uart1_handle, UART_IT_RXNE);  /* Enable RX not empty interrupt */
        
        /* Configure and enable USART1 interrupt */
        HAL_NVIC_SetPriority(USART1_IRQn, 3, 3);              /* Preemption priority 3, subpriority 3 */
        HAL_NVIC_EnableIRQ(USART1_IRQn);                      /* Enable USART1 interrupt */
#endif
    }
}

void USART1_IRQHandler(void)
{ 
    uint8_t data;
    
    /* Check if RXNE (Read data register not empty) flag is set */
    if ((__HAL_UART_GET_FLAG(&g_uart1_handle, UART_FLAG_RXNE) != RESET))
    {
        data = (uint8_t)(USART1->DR);  	/* Reading DR clears RXNE flag */
        protocol_recv(&data, 1);        /* 把接收到的串口数据放入环形缓冲区中 */
    }
}
/* I2C communication */
/******************************************************************************************/
/* 引脚 定义 */

#define IIC_SCL1_GPIO_PORT               GPIOB
#define IIC_SCL1_GPIO_PIN                GPIO_PIN_12
#define IIC_SCL1_GPIO_CLK_ENABLE()       do{ __HAL_RCC_GPIOB_CLK_ENABLE(); }while(0)   /* PB口时钟使能 */

#define IIC_SDA1_GPIO_PORT               GPIOB
#define IIC_SDA1_GPIO_PIN                GPIO_PIN_13
#define IIC_SDA1_GPIO_CLK_ENABLE()       do{ __HAL_RCC_GPIOB_CLK_ENABLE(); }while(0)   /* PB口时钟使能 */
/******************************************************************************************/

static void _iic1_init(ltm_iic_driver* iic)
{
    GPIO_InitTypeDef gpio_init_struct;

    IIC_SCL1_GPIO_CLK_ENABLE();  /* SCL引脚时钟使能 */
    IIC_SDA1_GPIO_CLK_ENABLE();  /* SDA引脚时钟使能 */

    gpio_init_struct.Pin = IIC_SCL1_GPIO_PIN;
    gpio_init_struct.Mode = GPIO_MODE_OUTPUT_PP;        /* 推挽输出 */
    gpio_init_struct.Pull = GPIO_PULLUP;                /* 上拉 */
    gpio_init_struct.Speed = GPIO_SPEED_FREQ_HIGH;      /* 高速 */
    HAL_GPIO_Init(IIC_SCL1_GPIO_PORT, &gpio_init_struct);/* SCL */

    gpio_init_struct.Pin = IIC_SDA1_GPIO_PIN;
    gpio_init_struct.Mode = GPIO_MODE_OUTPUT_OD;        /* 开漏输出 */
    HAL_GPIO_Init(IIC_SDA1_GPIO_PORT, &gpio_init_struct);/* SDA */
    /* SDA引脚模式设置,开漏输出,上拉, 这样就不用再设置IO方向了, 开漏输出的时候(=1), 也可以读取外部信号的高低电平 */
}

static void _iic1_scl(ltm_iic_driver* iic, uint8_t val)
{
	if(val) HAL_GPIO_WritePin(IIC_SCL1_GPIO_PORT, IIC_SCL1_GPIO_PIN, GPIO_PIN_SET);
	else 	HAL_GPIO_WritePin(IIC_SCL1_GPIO_PORT, IIC_SCL1_GPIO_PIN, GPIO_PIN_RESET);
}

static void _iic1_sda(ltm_iic_driver* iic, uint8_t val)
{
	if(val) HAL_GPIO_WritePin(IIC_SDA1_GPIO_PORT, IIC_SDA1_GPIO_PIN, GPIO_PIN_SET);
	else	HAL_GPIO_WritePin(IIC_SDA1_GPIO_PORT, IIC_SDA1_GPIO_PIN, GPIO_PIN_RESET);
}

static uint8_t _iic1_read_sda(ltm_iic_driver* iic)
{
	return HAL_GPIO_ReadPin(IIC_SDA1_GPIO_PORT, IIC_SDA1_GPIO_PIN); /* 读取SDA */
}

/********************************************************************************************/
/* communicator hardware implementation */
static struct lt_commut_ops commut_ops;
static struct ltm_iic_driver_ops iic1_ops;
static ltm_iic_driver iic1_driver;
ltm_iic_driver* iic1 = &iic1_driver;

static void _serial_send(uint8_t* buf, uint16_t len)
{
    HAL_UART_Transmit(&g_uart1_handle, buf, len, 200);
}

void drv_commut_init(void)
{
	usart_init(115200);
    protocol_init(0);                       //通讯协议初始化，不显示数据
#ifdef LT_COMMUTE_ENABLE
	struct lt_commut_config commut_config;
	commut_config.name = "commut";
	commut_config.ops = &commut_ops;
	lt_commut_set(&commut_config);
#endif

	ltm_iic_config iic_config;
	iic_config.addr =  0x3C;				
	iic_config.data_addr = 0x00;
	iic_config.ops = &iic1_ops;
	ltm_iic_set(iic1,&iic_config);			/* set iic driver */
}

static struct ltm_iic_driver_ops iic1_ops = {
									_iic1_init,
									_iic1_scl,
									_iic1_sda,
									_iic1_read_sda,
};

static struct lt_commut_ops commut_ops = {
                                    _serial_send,
};

