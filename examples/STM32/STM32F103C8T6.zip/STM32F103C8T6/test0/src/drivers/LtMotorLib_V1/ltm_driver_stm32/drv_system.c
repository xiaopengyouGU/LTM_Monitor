/*
 * SPDX-License-Identifier: Apache-2.0
 * Change Logs:
 * Date           Author       Notes
 * 2025-11-16     Lvtou        The first version
 * 2024-03-13     Modified     Adapted for STM32F103xE @72MHz
 */
#include "ltmotorlib.h"
#include "driver_def.h"

/**
 * @brief Initialize system clock for STM32F103xE @72MHz
 * @note  Uses HSE 8MHz oscillator with PLL multiplication
 * @note  For F103, PLL configuration is simpler: only PLLMUL matters
 * @return 0 on success, 1 on failure
 */
uint8_t sys_stm32_clock_init(void)
{
    HAL_StatusTypeDef ret = HAL_OK;
    RCC_OscInitTypeDef rcc_osc_init = {0};
    RCC_ClkInitTypeDef rcc_clk_init = {0};
    
    /* Enable HSE and set PLL to multiply by 9 -> 8MHz * 9 = 72MHz */
    rcc_osc_init.OscillatorType = RCC_OSCILLATORTYPE_HSE;        /* Clock source: HSE */
    rcc_osc_init.HSEState = RCC_HSE_ON;                          /* Enable HSE */
    rcc_osc_init.PLL.PLLState = RCC_PLL_ON;                      /* Enable PLL */
    rcc_osc_init.PLL.PLLSource = RCC_PLLSOURCE_HSE;              /* PLL source: HSE */
    
    /* STM32F103 PLL configuration (simpler than G4):
     * - PLLMUL: Multiplication factor (must be 6-16 for F103)
     * - For 72MHz: HSE 8MHz * 9 = 72MHz
     */
    rcc_osc_init.PLL.PLLMUL = RCC_PLL_MUL9;                      /* 8MHz * 9 = 72MHz */
    
    ret = HAL_RCC_OscConfig(&rcc_osc_init);                      /* Initialize RCC oscillator */
    if(ret != HAL_OK)
    {
        return 1;                                                /* Clock initialization failed */
    }

    /* Select PLL as system clock source, configure HCLK, PCLK1, PCLK2 */
    rcc_clk_init.ClockType = (RCC_CLOCKTYPE_SYSCLK | 
                               RCC_CLOCKTYPE_HCLK | 
                               RCC_CLOCKTYPE_PCLK1 | 
                               RCC_CLOCKTYPE_PCLK2);

    rcc_clk_init.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;         /* System clock source: PLL */
    rcc_clk_init.AHBCLKDivider = RCC_SYSCLK_DIV1;                /* AHB prescaler = 1, HCLK = 72MHz */
    rcc_clk_init.APB1CLKDivider = RCC_HCLK_DIV2;                 /* APB1 prescaler = 2, PCLK1 = 36MHz (max) */
    rcc_clk_init.APB2CLKDivider = RCC_HCLK_DIV1;                 /* APB2 prescaler = 1, PCLK2 = 72MHz */
    
    /* STM32F103 at 72MHz requires 2 wait states for Flash */
    ret = HAL_RCC_ClockConfig(&rcc_clk_init, FLASH_LATENCY_2);   /* Set Flash latency to 2 wait states */
    if(ret != HAL_OK)
    {
        return 1;                                                /* Clock configuration failed */
    }
    
    return 0;
}

/*****************************************************************************************/
static uint32_t g_fac_us = 0;       /* Timer ticks per microsecond */

/**
 * @brief Initialize delay function
 * @param sysclk System clock frequency in MHz (should be 72 for 72MHz)
 */
void delay_init(uint16_t sysclk)
{
    /* SYSTICK uses HCLK as clock source (72MHz for F103) */
    HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);
    g_fac_us = sysclk;                                           /* Store ticks per microsecond */
}

/**
 * @brief Microsecond delay
 * @param nus Number of microseconds to delay
 */
void delay_us(uint32_t nus)
{
    uint32_t ticks;
    uint32_t told, tnow, tcnt = 0;
    uint32_t reload = SysTick->LOAD;                             /* LOAD register value */
    ticks = nus * g_fac_us;                                      /* Required ticks */

    told = SysTick->VAL;                                         /* Previous counter value */
    while (1)
    {
        tnow = SysTick->VAL;
        if (tnow != told)
        {
            if (tnow < told)
            {
                tcnt += told - tnow;                             /* Note: SYSTICK is a down-counter */
            }
            else
            {
                tcnt += reload - tnow + told;
            }
            told = tnow;
            if (tcnt >= ticks) 
            {
                break;                                           /* Time exceeded, exit */
            }
        }
    }
}

/**
 * @brief Millisecond delay
 * @param nms Number of milliseconds to delay (0 < nms <= 65535)
 */
void delay_ms(uint16_t nms)
{
    delay_us((uint32_t)(nms * 1000));                            /* Convert ms to us */
}

/**
 * @brief HAL-compatible delay function
 * @note Overrides the default HAL_Delay if needed
 * @param Delay Milliseconds to delay
 */
void HAL_Delay(uint32_t Delay)
{
     delay_ms(Delay);
}

/*****************************************************************************************/
void ltm_driver_init(void)
{
	/* Init system at first !!! */
	drv_system_init();			
	/* then init device init */
	drv_commut_init();
	//drv_current_init();
	//drv_driver_init();
	//drv_timer_init();
	//drv_sensor_init();
	drv_debug_init();
	/* Init motor finally !!! */
	//drv_motor_init();		
}

void drv_system_init(void)
{
	HAL_Init();                                 /* init HAL Library */
    sys_stm32_clock_init();                     /* set system clock,170Mhz */
	delay_init(72);							    /* delay init */
}

void ltm_delay_us(uint32_t us)
{
	delay_us(us);
}

void ltm_delay_ms(uint32_t ms)
{
	 delay_us((uint32_t)(ms * 1000));                   /* ��ͨ��ʽ��ʱ */
}
