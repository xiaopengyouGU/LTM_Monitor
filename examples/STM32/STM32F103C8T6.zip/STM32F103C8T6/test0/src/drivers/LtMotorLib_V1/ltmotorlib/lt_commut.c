/*
 * SPDX-License-Identifier: Apache-2.0
 * Change Logs:
 * Date           Author       	Notes
 * 2025-12-5      Lvtou			The first version
 * 2026-2-26      Lvtou			The second version
 */
#include "ltmotorlib.h"
#include "protocol.h"

static struct lt_commut_object _commut_object;
static lt_commut_t commut = &_commut_object;

static void _commut_send(uint8_t data_type, uint8_t *datas, uint16_t len);
static void _commut_printf(const char *fmt, ...);

void lt_commut_send(uint8_t data_type, uint8_t *datas, uint16_t len)
{
#ifdef LT_DEBUG_ENABLE
	LT_CHECK_DEVICE(commut);
#endif
	_commut_send(data_type, datas, len);
}

void lt_commut_printf(const char *fmt, ...)
{
#ifdef LT_DEBUG_ENABLE
    LT_CHECK_DEVICE(commut);
#endif
    if (fmt == NULL) return;
	_commut_printf(fmt);
}

//通道的发送接口部分，ch 取值为 1 —— 5
void lt_commut_send_curve(uint8_t ch, float value)
{
#ifdef LT_DEBUG_ENABLE
	LT_CHECK_DEVICE(commut);
#endif
	if(ch > 5 || ch < 1) return;
	_commut_send(Data_Channel1 + ch - 1, (uint8_t *)&value, sizeof(value));
}

void lt_commut_set(struct lt_commut_config* config)
{
#ifdef LT_DEBUG_ENABLE
	LT_CHECK_NULL(commut);
	LT_CHECK_NULL(config);
	LT_CHECK_NULL(config->ops);
	LT_CHECK_NULL(config->ops->send);
#endif
	memset(commut,0,sizeof(struct lt_commut_object));
	if(config->name != NULL)
	{
		strcpy(commut->name,config->name);
	}
	commut->ops =	config->ops;
	
	commut->flag |= DEVICE_FLAG_INIT;
	commut->flag |= DEVICE_FLAG_CHECKED;
}

void lt_commut_set_motor(lt_motor_t motor, uint8_t pid_type)
{
#ifdef LT_DEBUG_ENABLE
	LT_CHECK_DEVICE(commut);
	LT_CHECK_MOTOR(motor);
#endif
	lt_pid_t pid;
	switch (pid_type)
	{
		case PID_TYPE_POS:
		{
			pid = motor->pos_pid;
			break;
		}
		case PID_TYPE_VEL:
		{
			pid = motor->vel_pid;
			break;
		}
		case PID_TYPE_CURR_D:
		{
			pid = motor->curr_pid_d;
			break;
		}
		case PID_TYPE_CURR_Q:
		{
			pid = motor->curr_pid_q;
			break;
		}
		default:break;
	}
#ifdef LT_DEBUG_ENABLE
	LT_CHECK_NULL(pid);
#endif	
	commut->motor = motor;
	commut->pid = pid;
}

void lt_commut_process(void)
{
#ifdef LT_DEBUG_ENABLE
	LT_CHECK_DEVICE(commut);
#endif
	uint8_t *buf = commut->datas;
	uint8_t data_type = Data_Unknown;			//未知数据,说明接收错误或数据不完整
	uint16_t len;

	if(!protocol_process(&data_type, buf, &len))	return;//未接收到完整的数据帧
	commut->len = len;
	commut->data_type = data_type;

	//switch case
	switch(data_type)
	{
		case Data_CMD_Text:						//接收到文本指令
		{										//回复 : 接收到的指令
			_commut_send(data_type, buf, len);
			break;
		}
		case Data_CMD_Start:
		{
			_commut_send(Data_Res_Start, &data_type, 1);
			break;
		}
		case Data_CMD_Stop:
		{
			_commut_send(Data_Res_Stop, &data_type, 1);
			break;
		}
		case Data_Target:						//目标值 
		{
			float value = 0;
			memcpy(&value, buf, sizeof(float));
    		_commut_printf("Target: %d", (int)value);
			break;
		}
		default: break;
	}
}


/***************************************************************************************/
static void _commut_send(uint8_t data_type, uint8_t *datas, uint16_t len)
{
	if(datas == NULL || len == 0) return;

	uint8_t *buf;
	protocol_package(data_type, datas, len);  //数据打包
    buf = protocol_datas(&len);         	  //获取打包后的数据
	commut->ops->send(buf, len);			  //利用串口发送打包后的数据到下位机
}

static void _commut_printf(const char *fmt, ...)
{
	
    char buffer[64];          
    va_list args;
    va_start(args, fmt);
    int len = vsnprintf(buffer, sizeof(buffer), fmt, args);
    va_end(args);

    if (len < 0) return;       	   // 格式化失败
    if (len >= (int)sizeof(buffer)) {
        len = sizeof(buffer) - 1;  // 截断，但确保缓冲区末尾有 '\0'（vsnprintf已保证）
    }

    // 将格式化后的字符串作为文本指令发送
    _commut_send(Data_CMD_Text, (uint8_t*)buffer, len);
}