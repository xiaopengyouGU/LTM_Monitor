/*
 * SPDX-License-Identifier: Apache-2.0
 * Change Logs:
 * Date           Author       Notes
 * 2025-11-16     Lvtou        The first version
 * 2024-03-13     Modified     Adapted for STM32F103xE
 */
#include "ltmotorlib.h"
#include "driver_def.h"

lt_current_t current;

DMA_HandleTypeDef g_dma_adc_handle;                         /* DMA handle for ADC */
ADC_HandleTypeDef g_adc_handle;                             /* ADC handle */
uint16_t g_adc_dma_buf[ADC_SUM];                            /* Buffer for ADC raw values */

/**
 * @brief Configure ADC channel
 * @param adc_handle ADC handle pointer
 * @param ch ADC channel
 * @param rank Conversion rank (1-16)
 * @param stime Sampling time
 */
void adc_channel_set(ADC_HandleTypeDef *adc_handle, uint32_t ch, uint32_t rank, uint32_t stime)
{
    ADC_ChannelConfTypeDef adc_channel;
    adc_channel.Channel = ch;                   /* ADC channel */
    adc_channel.Rank = rank;                    /* Conversion rank */
    adc_channel.SamplingTime = stime;           /* Sampling time */
    HAL_ADC_ConfigChannel(adc_handle, &adc_channel);   
}

/**
 * @brief Initialize ADC
 * @param flag Operation mode flag
 */
void adc_init(uint8_t flag)
{
    if(flag == DEVICE_FLAG_CALIBING)    /* Start calibrating mode */
    {
        g_adc_handle.Init.ContinuousConvMode = ENABLE;              /* Enable continuous conversion */
        g_adc_handle.Init.ExternalTrigConv = ADC_SOFTWARE_START;    /* Software trigger */
    }
    else if(flag == DEVICE_FLAG_CALIB)  /* Calibrated successfully, normal operation */
    {
        g_adc_handle.Init.ContinuousConvMode = DISABLE;             /* Disable continuous conversion */
        //g_adc_handle.Init.ExternalTrigConv = ADC_EXTERNALTRIGCONV_T8_TRGO; /* TIM8 trigger */
    }
    else return;
    
    /* ADC Common Configuration for STM32F103 */
    g_adc_handle.Instance = ADC1;                                    /* Use ADC1 for F103 */
    g_adc_handle.Init.DataAlign = ADC_DATAALIGN_RIGHT;               /* Right alignment */
    g_adc_handle.Init.ScanConvMode = ENABLE;                         /* Enable scan mode */
    g_adc_handle.Init.ContinuousConvMode = g_adc_handle.Init.ContinuousConvMode; /* Set from above */
    g_adc_handle.Init.NbrOfConversion = ADC_CH_NUM;                  /* Number of conversions */
    g_adc_handle.Init.DiscontinuousConvMode = DISABLE;               /* Disable discontinuous mode */
    g_adc_handle.Init.ExternalTrigConv = g_adc_handle.Init.ExternalTrigConv; /* Set from above */
    g_adc_handle.Init.NbrOfDiscConversion = 0;                       /* Discontinuous conversions = 0 */
    
    HAL_ADC_Init(&g_adc_handle);                                     /* Initialize ADC */
    
    /* F103 uses different calibration method */
    HAL_ADCEx_Calibration_Start(&g_adc_handle);                      /* Start ADC calibration */
}

/**
 * @brief ADC MSP Initialization
 * @param hadc ADC handle pointer
 */
void HAL_ADC_MspInit(ADC_HandleTypeDef *hadc)
{
    if(hadc->Instance == ADC1)
    {
        GPIO_InitTypeDef gpio_init_struct;
        
        /* Enable ADC1 and GPIO clocks */
        __HAL_RCC_ADC1_CLK_ENABLE();
        __HAL_RCC_GPIOA_CLK_ENABLE();
        __HAL_RCC_GPIOB_CLK_ENABLE();
        
        /* F103: ADC clock is from PCLK2 with max 14MHz (for 12-bit resolution)
         * For 72MHz PCLK2, use 6分频: 72/6 = 12MHz (<14MHz OK) */
        __HAL_RCC_ADC_CONFIG(RCC_ADCPCLK2_DIV6);
        
        /* Configure GPIO pins in analog mode */
        /* Channel 0: U-phase current (PA0) */
        gpio_init_struct.Pin = GPIO_PIN_0;
        gpio_init_struct.Mode = GPIO_MODE_ANALOG;
        HAL_GPIO_Init(GPIOA, &gpio_init_struct);
        
        /* Channel 1: V-phase current (PA1) */
        gpio_init_struct.Pin = GPIO_PIN_1;
        HAL_GPIO_Init(GPIOA, &gpio_init_struct);
        
        /* Channel 2: W-phase current (PA2) */
        gpio_init_struct.Pin = GPIO_PIN_2;
        HAL_GPIO_Init(GPIOA, &gpio_init_struct);
        
        /* Channel 3: Bus voltage (PA3) */
        gpio_init_struct.Pin = GPIO_PIN_3;
        HAL_GPIO_Init(GPIOA, &gpio_init_struct);
        
        /* Channel 8: Temperature (PB0) - Note: F103 ADC1 only has channels 0-15 on specific pins */
        gpio_init_struct.Pin = GPIO_PIN_0;
        HAL_GPIO_Init(GPIOB, &gpio_init_struct);
        
        /* For F103, you may need to map your actual pin connections:
         * ADC1_IN0: PA0, ADC1_IN1: PA1, ADC1_IN2: PA2, ADC1_IN3: PA3
         * ADC1_IN8: PB0, ADC1_IN9: PB1, ADC1_IN10: PC0, ADC1_IN11: PC1
         * ADC1_IN12: PC2, ADC1_IN13: PC3, ADC1_IN14: PC4, ADC1_IN15: PC5 */
    }
}

/**
 * @brief Initialize ADC with DMA
 * @param flag Operation mode flag
 */
void adc_dma_init(uint8_t flag)
{
    /* Enable DMA1 clock (F103 uses DMA1) */
    __HAL_RCC_DMA1_CLK_ENABLE();
    
    /* DMA configuration for ADC1 */
    g_dma_adc_handle.Instance = DMA1_Channel1;                      /* ADC1 uses DMA1 Channel1 */
    g_dma_adc_handle.Init.Direction = DMA_PERIPH_TO_MEMORY;         /* Peripheral to memory */
    g_dma_adc_handle.Init.PeriphInc = DMA_PINC_DISABLE;             /* Peripheral address fixed */
    g_dma_adc_handle.Init.MemInc = DMA_MINC_ENABLE;                 /* Memory increment enabled */
    g_dma_adc_handle.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD; /* 16-bit peripheral */
    g_dma_adc_handle.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;    /* 16-bit memory */
    g_dma_adc_handle.Init.Mode = DMA_CIRCULAR;                      /* Circular mode */
    g_dma_adc_handle.Init.Priority = DMA_PRIORITY_MEDIUM;           /* Medium priority */
    
    HAL_DMA_Init(&g_dma_adc_handle);                                /* Initialize DMA */
    
    /* Link DMA to ADC */
    __HAL_LINKDMA(&g_adc_handle, DMA_Handle, g_dma_adc_handle);
    
    adc_init(flag);                                                 /* Initialize ADC */
    
    /* Configure ADC channels with appropriate sampling times */
    /* For F103, sampling times: 1.5, 7.5, 13.5, 28.5, 41.5, 55.5, 71.5, 239.5 cycles */
    adc_channel_set(&g_adc_handle, ADC_CHANNEL_0, 1, ADC_SAMPLETIME_55CYCLES_5);  /* U-phase */
    adc_channel_set(&g_adc_handle, ADC_CHANNEL_1, 2, ADC_SAMPLETIME_55CYCLES_5);  /* V-phase */
    adc_channel_set(&g_adc_handle, ADC_CHANNEL_2, 3, ADC_SAMPLETIME_55CYCLES_5);  /* W-phase */
    adc_channel_set(&g_adc_handle, ADC_CHANNEL_3, 4, ADC_SAMPLETIME_55CYCLES_5);  /* Bus voltage */
    adc_channel_set(&g_adc_handle, ADC_CHANNEL_8, 5, ADC_SAMPLETIME_239CYCLES_5); /* Temperature (slow) */
    
    /* Configure DMA interrupt */
    HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 2, 3);                 /* Set DMA interrupt priority */
    HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);                         /* Enable DMA interrupt */
    
    /* Start ADC with DMA */
    HAL_ADC_Start_DMA(&g_adc_handle, (uint32_t*)g_adc_dma_buf, ADC_SUM);
}

/* DMA1 Channel1 Interrupt Handler (for ADC) */
void DMA1_Channel1_IRQHandler(void)
{
    HAL_DMA_IRQHandler(&g_dma_adc_handle);
}

/**
 * @brief Start ADC calibration process
 */
void adc_start_calibration(void)
{
    adc_dma_init(DEVICE_FLAG_CALIBING);    /* Start in calibration mode */
}

/**
 * @brief Complete ADC calibration and start normal operation
 */
void adc_calibration_complete(void)
{
    /* Reinitialize ADC with normal operation parameters */
    adc_dma_init(DEVICE_FLAG_CALIB);
}

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{
    if (hadc->Instance == ADC1) 
    { 
		if(!(current->flag & DEVICE_FLAG_CALIB))					/* haven't calibrate */
		{
			HAL_ADC_Stop_DMA(&g_adc_handle);                      	/* Stop DMA at first */
			uint8_t i,j;
			for(i = 0; i < ADC_DMA_BUF_SIZE; i++)
			{
				for(j = 0; j < 3; j++)
				{
					current->bias[j] += g_adc_dma_buf[i*5 + j];
				}
			}
			/* get average values */
			for(j = 0; j < 3; j++)
			{
				current->bias[j] /= ADC_DMA_BUF_SIZE;
			}
			current->flag |= DEVICE_FLAG_CALIB;						/* finish current sense calibration */
		}
		else
		{
			ltm_motor_run(LOOP_FLAG_CURRENT);						/* start motor control*/
			/* trigger FOC calculation  thread */
		}
    }
}


const float Rp = 10000.0f;                  /* 10K */
const float T2 = (273.15f + 25.0f);         /* T2 */
const float Bx = 3380.0f;                   /* B */
const float Ka = 273.15f;

float get_temp(uint16_t para)
{
    float Rt;
    float temp;
    Rt = 3.3f * 4700.0f / (para * 3.3f / 4096.0f) - 4700.0f;
    /* like this R=5000, T2=273.15+25,B=3470, RT=5000*EXP(3470*(1/T1-1/(273.15+25)) */
    temp = Rt / Rp;
    //temp = log(temp);       /* ln(Rt/Rp) */
    temp /= Bx;             /* ln(Rt/Rp)/B */
    temp += (1.0f / T2);
    temp = 1.0f / (temp);
    temp -= Ka;
    return temp;
}
/********************************************************************************************/
/* current device operators' hardware implementation */
static struct lt_current_ops ops;

void drv_current_init(void)
{	
	/* create current sense device */
	if(current != NULL) return;			/* avoid repeated initialization */
	current = lt_current_create("current");
	if(current == NULL) return;
	/* config current device */
	struct lt_current_config config;
	config.name = NULL;
	config.amp_gain = 6;
	config.bit_num = 12;
	config.vbus_gain = 1.0f/25;
	config.get_temp = get_temp;
	config.resistor = 0.020;		/* 20 mOhm */
	config.ops = &ops;
	config.type = CURRENT_TYPE_3;
	
	lt_current_set(current,&config);
}


static void _adc_calibrate(lt_current_t current)
{
	adc_dma_init(DEVICE_FLAG_CALIBING);
	HAL_ADC_Start_DMA(&g_adc_handle, (uint32_t *)&g_adc_dma_buf, ADC_SUM); 		/* Start DMA conversion */
}

static void _adc_start(lt_current_t current)
{
	if(current->flag & DEVICE_FLAG_CALIBING)	/* first calibrate successfully, we need to init adc again */
	{
		adc_dma_init(DEVICE_FLAG_CALIB);
		current->flag = CLEAR_BITS(current->flag, DEVICE_FLAG_CALIBING);		/* clear clibing flag */
	}
	HAL_ADC_Start_DMA(&g_adc_handle, (uint32_t *)&(current->vals), ADC_CH_NUM); /* Start DMA conversion */
}

static void _adc_stop(lt_current_t current)
{
	HAL_ADC_Stop_DMA(&g_adc_handle);
}

static struct lt_current_ops ops = {	
										_adc_calibrate,
										_adc_start,
										_adc_stop,
};


