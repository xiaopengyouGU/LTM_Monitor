./objects/protocol.o: src\protocol\protocol.c src\protocol\protocol.h \
  D:\GoodThing\MDK\ARM\ARMCLANG\Bin\..\include\stdint.h \
  D:\GoodThing\MDK\ARM\ARMCLANG\Bin\..\include\stdbool.h \
  D:\GoodThing\MDK\ARM\ARMCLANG\Bin\..\include\string.h \
  D:\GoodThing\MDK\ARM\ARMCLANG\Bin\..\include\stdio.h
