./objects/main.o: \
  D:\BaiduNetdiskDownload\RA6T2\003_Basic_UART_Receive_Send\ra_gen\main.c \
  ra_gen\hal_data.h \
  D:\GoodThing\MDK\ARM\ARMCLANG\Bin\..\include\stdint.h \
  ra\fsp\inc\api\bsp_api.h ra\fsp\inc\api\fsp_common_api.h \
  D:\GoodThing\MDK\ARM\ARMCLANG\Bin\..\include\assert.h \
  ra\fsp\inc\fsp_version.h ra_cfg\fsp_cfg\bsp\bsp_cfg.h \
  ra_gen\bsp_clock_cfg.h ra_cfg\fsp_cfg\bsp\bsp_mcu_family_cfg.h \
  ra_cfg\fsp_cfg\bsp\bsp_mcu_device_pn_cfg.h \
  ra_cfg\fsp_cfg\bsp\bsp_mcu_device_cfg.h \
  ra_cfg\fsp_cfg\bsp\..\..\..\ra\fsp\src\bsp\mcu\ra6t2\bsp_override.h \
  ra_cfg\fsp_cfg\bsp\..\..\..\ra\fsp\src\bsp\mcu\ra6t2\bsp_elc.h \
  ra_cfg\fsp_cfg\bsp\..\..\..\ra\fsp\src\bsp\mcu\ra6t2\bsp_mcu_info.h \
  ra_cfg\fsp_cfg\bsp\..\..\..\ra\fsp\src\bsp\mcu\ra6t2\bsp_feature.h \
  ra_cfg\fsp_cfg\bsp\..\..\..\ra\fsp\src\bsp\mcu\ra6t2\bsp_peripheral.h \
  ra_cfg\fsp_cfg\bsp\..\..\..\ra\fsp\src\bsp\mcu\ra6t2\r_adc_device_types.h \
  ra_cfg\fsp_cfg\bsp\bsp_mcu_ofs_cfg.h ra_cfg\fsp_cfg\bsp\board_cfg.h \
  ra_gen\vector_data.h \
  ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_exceptions.h \
  ra\fsp\inc\api\..\..\src\bsp\cmsis\Device\RENESAS\Include\renesas.h \
  ra\arm\CMSIS_6\CMSIS\Core\Include\cmsis_compiler.h \
  ra\arm\CMSIS_6\CMSIS\Core\Include\cmsis_armclang.h \
  D:\GoodThing\MDK\ARM\ARMCLANG\Bin\..\include\arm_acle.h \
  ra\arm\CMSIS_6\CMSIS\Core\Include\.\m-profile\cmsis_armclang_m.h \
  ra\fsp\inc\api\..\..\src\bsp\cmsis\Device\RENESAS\Include\R7FA6T2BD.h \
  ra\arm\CMSIS_6\CMSIS\Core\Include\core_cm33.h \
  ra\arm\CMSIS_6\CMSIS\Core\Include\cmsis_version.h \
  ra\arm\CMSIS_6\CMSIS\Core\Include\cmsis_compiler.h \
  ra\arm\CMSIS_6\CMSIS\Core\Include\m-profile\armv8m_mpu.h \
  ra\fsp\inc\api\..\..\src\bsp\cmsis\Device\RENESAS\Include\system.h \
  ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_common.h \
  D:\GoodThing\MDK\ARM\ARMCLANG\Bin\..\include\stddef.h \
  D:\GoodThing\MDK\ARM\ARMCLANG\Bin\..\include\stdbool.h \
  D:\GoodThing\MDK\ARM\ARMCLANG\Bin\..\include\string.h \
  ra\fsp\inc\api\..\..\inc\api\fsp_common_api.h \
  ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_compiler_support.h \
  ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_tfu.h \
  D:\GoodThing\MDK\ARM\ARMCLANG\Bin\..\include\math.h \
  ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_sdram.h \
  ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_mmf.h \
  ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_ipc.h \
  ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_ospi_b.h \
  D:\BaiduNetdiskDownload\RA6T2\003_Basic_UART_Receive_Send\bsp_linker_info.h \
  ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_register_protection.h \
  ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_irq.h \
  ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_io.h \
  ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_group_irq.h \
  ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_clocks.h \
  ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_module_stop.h \
  ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_security.h \
  ra\fsp\inc\api\..\..\inc\fsp_features.h \
  ra\fsp\inc\api\fsp_common_api.h \
  ra\fsp\inc\..\..\fsp\src\bsp\mcu\all\bsp_compiler_support.h \
  ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_delay.h \
  ra\fsp\inc\api\..\..\src\bsp\mcu\all\bsp_mcu_api.h \
  ra_gen\common_data.h ra\fsp\inc\instances\r_ioport.h \
  ra\fsp\inc\api\r_ioport_api.h ra\fsp\inc\api\bsp_api.h \
  ra_cfg\fsp_cfg\r_ioport_cfg.h ra_cfg\fsp_cfg\bsp\bsp_pin_cfg.h \
  ra\fsp\inc\instances\r_sci_b_uart.h ra\fsp\inc\api\r_uart_api.h \
  ra\fsp\inc\api\r_transfer_api.h ra_cfg\fsp_cfg\r_sci_b_uart_cfg.h
