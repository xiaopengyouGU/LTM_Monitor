./objects/ltm_commut.o: src\protocol\ltm_commut.c \
  src\protocol\ltm_commut.h src\protocol\protocol.h \
  D:\GoodThing\MDK\ARM\ARMCLANG\Bin\..\include\stdint.h \
  D:\GoodThing\MDK\ARM\ARMCLANG\Bin\..\include\stdbool.h \
  D:\GoodThing\MDK\ARM\ARMCLANG\Bin\..\include\string.h \
  D:\GoodThing\MDK\ARM\ARMCLANG\Bin\..\include\stdio.h \
  D:\GoodThing\MDK\ARM\ARMCLANG\Bin\..\include\stdarg.h
