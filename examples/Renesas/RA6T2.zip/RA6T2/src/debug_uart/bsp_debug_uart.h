#ifndef __BSP_DEBUG_UART_H
#define	__BSP_DEBUG_UART_H
#include "hal_data.h"
#include "stdio.h"


void Debug_UART9_Init(void);
void Debug_Write(uint8_t* buf, uint16_t len);
void Debug_Set_Rxcall(void(*rxcall)(uint8_t* buf, uint16_t len));


#endif
